package com.company;

public class ThreeDobjects {
	double radius;
	int id;
	
	public void print() {
		System.out.println("This is a 3D object");
	}
}
